# The Case of the Missing Heart ❤️‍🩹

A romantic detective mystery for Wijdane. This is a static website designed to run on GitHub Pages at no cost.

## Files

- `index.html` — complete site, styles, six interactive stages, and final letter.

## Publish with GitHub Pages (free)

1. Sign in or create an account at https://github.com/
2. Create a new repository, for example `missing-heart`.
3. Upload `index.html` to the repository's root (the top level).
4. Open **Settings → Pages**.
5. Under **Build and deployment**, select **Deploy from a branch**.
6. Choose the `main` branch and `/(root)`, then save.
7. Wait for GitHub Pages to publish. The site URL will appear in the Pages settings, usually in the form `https://YOUR-USERNAME.github.io/missing-heart/`.
8. Open the link on your phone to test it, then send it to Wijdane.

## Personalize the clues and letter

Open `index.html` in a text editor.

- The six clues are in the `stages` array inside the `<script>` section.
- For Stage 2, replace the generic place answer in `answer: [...]` with a specific memory or place that only the two of you know. Keep the matching answer in lowercase.
- Edit the final letter inside `renderLetter()` to sound like you. Add your name or a private nickname if you wish.
- You can change the title and introduction by searching for `Wijdane`.

## Important privacy note

This is a static client-side puzzle. It is free and simple, but the accepted answers are included in the page source, so a technically curious visitor could inspect them. Do not put passwords, private account details, or genuinely sensitive information into the clues. GitHub Pages also makes the published page public to anyone with the URL unless you use a different hosting/access setup.
